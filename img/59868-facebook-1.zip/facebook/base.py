# go through category list, save all ids as individual objects into index
# if the result has paging.next - you can use paging.cursors.after to retrieve the next query.

from pymongo import MongoClient

import time
import datetime

import config

class BaseClass(object):

	def __init__(self):
		self.init_db( )

	def init_db(self):
		mongo = MongoClient(config.db_location, config.db_port)
		self.db = mongo[config.db_name]

	def get_timestamp(self):
		temp = { }

		ts = time.time( )
		ts_f = datetime.datetime.fromtimestamp(ts).strftime('%Y-%m-%d %H:%M:%S')

		temp['timestamp'] = ts
		temp['timestamp_formatted'] = ts_f

		return temp

	def get_counter(self, counter_name):
		collection = self.db['counters']
		res = collection.find_and_modify({"_id": counter_name}, {"$inc": { "seq": 1 } }, new=True)

		if res is None: # add the entry
			collection.insert({"_id": counter_name, "seq": 0})
			return 0
		else:
			return res['seq']




