"""
This program is to poll/graph subscribe to updates at a high frequency
1. update page data.

2. get all posts on page.

3. create content identifiers:
Types:
IMAGE - URL and HASH
SITE  - URL
MEDIA - URL and HASH


4. pull in comments, items with media/images/urls get treated as "content" with a back identifier to the post_id & comment_id


FB_PAGE_SCHEMA:
_____________________
pull_date :
likes :
shares :
past_scrapes : past like and share data.
id :
hit_list_id : id if applicable
??????
_____________________


FB_POST_SCHEMA:
_____________________
pull_date :
post_date :
post_index :
post :
page_id :
_____________________


FB_COMMENT_SCHEMA:
_____________________
pull_date :
comment_date :
comment_index :
comment :
post_id :
page_id :
_____________________


CONTENT_SCHEMA ( WIP - need more sources. ):
_____________________
pull_date :
type : IMAGE/SITE/MEDIA
url : URL
hash : HASH only if applicable
from : POST/COMMENT
origin : FACEBOOK/?
post_id : 
comment_id : 
page_id : 
?????
_____________________


FOUND_LINK_SCHEMA:
_____________________
pull_date:
origin:
linked_content: [ content ids ]
????
_____________________
""" 












