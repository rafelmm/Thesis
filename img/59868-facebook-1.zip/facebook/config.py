# -*- coding: utf-8 -*-

# fb info
fb_token = "333849473473045|06e1eca69b6ba3ca5b34e178950b6540"

# mongo info
db_location ='localhost'
db_port = 27017
db_name = 'scrape'

# public json format endpoint
# fb_public_endpoint = "https://www.facebook.com/feeds/page.php?id=%s&format=json"

# typical public endpoint
fb_public_endpoint = "https://www.facebook.com/%s"


# retrieved by: search?type=placetopic&topic_filter=all
# see: https://developers.facebook.com/docs/graph-api/using-graph-api/v2.2#search
# TODO: dynamic each run.
# TODO: expand with other topics.
categories = [
	{
		"id": "151676848220295", 
		"name": "Education"
	}, 
	{
		"id": "161516070564222", 
		"name": "Financial Services"
	}, 
	{
		"id": "165679780146824", 
		"name": "Food & Restaurant"
	}, 
	{
		"id": "161811347201528", 
		"name": "Lodging"
	}, 
	{
		"id": "145118935550090", 
		"name": "Medical & Health"
	}, 
	{
		"id": "144982405562750", 
		"name": "Pet Service"
	}, 
	{
		"id": "148932728496725", 
		"name": "Public Places & Attractions"
	}, 
	{
		"id": "139460309451166", 
		"name": "Religious Center"
	}, 
	{
		"id": "192049437499122", 
		"name": "Residence & Other"
	}, 
	{
		"id": "273819889375819", 
		"name": "Restaurant"
	}, 
	{
		"id": "139225689474222", 
		"name": "Spa, Beauty & Personal Care"
	}, 
	{
		"id": "133436743388217", 
		"name": "Arts & Entertainment"
	}, 
	{
		"id": "180410821995109", 
		"name": "Automotive"
	}, 
	{
		"id": "187133811318958", 
		"name": "Business Services"
	}, 
	{
		"id": "188662441155211", 
		"name": "Community & Government"
	}, 
	{
		"id": "193705277324704", 
		"name": "Event Planning"
	}, 
	{
		"id": "150108431712141", 
		"name": "Food & Grocery"
	}, 
	{
		"id": "108427109235243", 
		"name": "Home Improvement"
	}, 
	{
		"id": "176831012360626", 
		"name": "Professional Services"
	}, 
	{
		"id": "198327773511962", 
		"name": "Real Estate"
	}, 
	{
		"id": "200600219953504", 
		"name": "Shopping & Retail"
	}, 
	{
		"id": "186982054657561", 
		"name": "Sports & Recreation"
	}, 
	{
		"id": "124861974254366", 
		"name": "Tours & Sightseeing"
	}, 
	{
		"id": "128232937246338", 
		"name": "Travel & Transportation"
	}, 
	{
		"id": "165156546872599", 
		"name": "Abortion Services"
	}, 
	{
		"id": "185127444860544", 
		"name": "Accessories Store"
	}, 
	{
		"id": "139976092733827", 
		"name": "Accountant"
	}, 
	{
		"id": "211799228831980", 
		"name": "Active Life"
	}, 
	{
		"id": "121549447920861", 
		"name": "Acupuncture"
	}, 
	{
		"id": "187062101324297", 
		"name": "Addiction Resources"
	}, 
	{
		"id": "163917800330437", 
		"name": "Admissions Training"
	}, 
	{
		"id": "193245447371023", 
		"name": "Adoption Service"
	}, 
	{
		"id": "127610667306994", 
		"name": "Adult Education"
	}, 
	{
		"id": "187623434605561", 
		"name": "Adult Entertainment"
	}, 
	{
		"id": "164886566892249", 
		"name": "Advertising Agency"
	}, 
	{
		"id": "163272113725616", 
		"name": "Advertising Service"
	}, 
	{
		"id": "121058704635534", 
		"name": "Afghani Restaurant"
	}, 
	{
		"id": "141538499244285", 
		"name": "African Methodist Episcopal Church"
	}, 
	{
		"id": "171226896258682", 
		"name": "African Restaurant"
	}, 
	{
		"id": "189323644423254", 
		"name": "Agricultural Service"
	}, 
	{
		"id": "169421023103905", 
		"name": "AIDS Resources"
	}, 
	{
		"id": "110192549061839", 
		"name": "Airline"
	}, 
	{
		"id": "180428515332153", 
		"name": "Airline Industry Services"
	}, 
	{
		"id": "223760917681177", 
		"name": "Airport Lounge"
	}, 
	{
		"id": "170817119631096", 
		"name": "Airport Shuttle"
	}, 
	{
		"id": "177950465654024", 
		"name": "Airport Terminal"
	}, 
	{
		"id": "181044611932826", 
		"name": "Allergist"
	}, 
	{
		"id": "210079735671721", 
		"name": "Allergy Doctor"
	}, 
	{
		"id": "357645644269220", 
		"name": "Alternative & Holistic Health"
	}, 
	{
		"id": "163102447071743", 
		"name": "Ambulance & Rescue"
	}, 
	{
		"id": "149803325077018", 
		"name": "American Restaurant"
	}, 
	{
		"id": "124994474239211", 
		"name": "Amusement"
	}, 
	{
		"id": "220626791295805", 
		"name": "Amusement Park Ride"
	}, 
	{
		"id": "139801652749645", 
		"name": "Anglican Church"
	}, 
	{
		"id": "170810676298376", 
		"name": "Animal Shelter"
	}, 
	{
		"id": "150732438316813", 
		"name": "Antique Store"
	}, 
	{
		"id": "417935738217839", 
		"name": "Antiques & Vintage"
	}, 
	{
		"id": "181216025249367", 
		"name": "Apartment & Condo Building"
	}, 
	{
		"id": "199448423406078", 
		"name": "Apostolic Church"
	}, 
	{
		"id": "124617867610922", 
		"name": "Appliances"
	}, 
	{
		"id": "187852234570429", 
		"name": "Appraiser"
	}, 
	{
		"id": "164409566941435", 
		"name": "Arcade"
	}, 
	{
		"id": "176393675739023", 
		"name": "Archaeological Services"
	}, 
	{
		"id": "170715949640891", 
		"name": "Archery"
	}, 
	{
		"id": "144835265576678", 
		"name": "Architect"
	}, 
	{
		"id": "205735146122517", 
		"name": "Argentine Restaurant"
	}, 
	{
		"id": "188166377871384", 
		"name": "Armed Forces"
	}, 
	{
		"id": "192068767488407", 
		"name": "Armored Cars"
	}, 
	{
		"id": "259030350843802", 
		"name": "Aromatherapy"
	}, 
	{
		"id": "197384240287028", 
		"name": "Art Gallery"
	}, 
	{
		"id": "384382644921530", 
		"name": "Art Museum"
	}, 
	{
		"id": "109499672460251", 
		"name": "Art Restoration"
	}, 
	{
		"id": "164288046954643", 
		"name": "Art School"
	}, 
	{
		"id": "199732070036794", 
		"name": "Artistic Services"
	}, 
	{
		"id": "153635828025130", 
		"name": "Arts & Crafts Supply Store"
	}, 
	{
		"id": "367960506579477", 
		"name": "Arts & Marketing"
	}, 
	{
		"id": "174201535963762", 
		"name": "Asian Fusion Restaurant"
	}, 
	{
		"id": "185855984789970", 
		"name": "Asian Restaurant"
	}, 
	{
		"id": "186312161401260", 
		"name": "Assembly of God"
	}, 
	{
		"id": "139495282781502", 
		"name": "Athletic Education"
	}, 
	{
		"id": "140465079350430", 
		"name": "ATVs & Golf Carts"
	}, 
	{
		"id": "192422584121096", 
		"name": "Auction House"
	}, 
	{
		"id": "199024153446160", 
		"name": "Audiologist"
	}, 
	{
		"id": "198632653485894", 
		"name": "Audiovisual Equipment"
	}, 
	{
		"id": "203246076360322", 
		"name": "Auditorium"
	}, 
	{
		"id": "188462984509706", 
		"name": "Auto Body Shop"
	}, 
	{
		"id": "153084451411848", 
		"name": "Auto Glass"
	}, 
	{
		"id": "153535891368765", 
		"name": "Automation Services"
	}, 
	{
		"id": "134088753324121", 
		"name": "Automobile Leasing"
	}, 
	{
		"id": "184888278217935", 
		"name": "Automotive Consultant"
	}, 
	{
		"id": "186712678028215", 
		"name": "Automotive Customizing"
	}, 
	{
		"id": "188620891159326", 
		"name": "Automotive Manufacturing"
	}, 
	{
		"id": "139492049448901", 
		"name": "Automotive Parts & Accessories"
	}, 
	{
		"id": "149998721725634", 
		"name": "Automotive Repair"
	}, 
	{
		"id": "124718197599943", 
		"name": "Automotive Restoration"
	}, 
	{
		"id": "196516643707440", 
		"name": "Automotive Storage"
	}, 
	{
		"id": "180913165284066", 
		"name": "Automotive Trailer Services"
	}, 
	{
		"id": "192507514101309", 
		"name": "Automotive Wholesaler"
	}, 
	{
		"id": "188317157856409", 
		"name": "Aviation Fuel"
	}, 
	{
		"id": "186032081419494", 
		"name": "Aviation School"
	}, 
	{
		"id": "189183707768885", 
		"name": "Awnings & Canopies"
	}, 
	{
		"id": "212086618801415", 
		"name": "Babysitter"
	}, 
	{
		"id": "161785987204191", 
		"name": "Bail Bonds"
	}, 
	{
		"id": "187827497907070", 
		"name": "Bakery"
	}, 
	{
		"id": "180164648685982", 
		"name": "Bands & Musicians"
	}, 
	{
		"id": "133576170041936", 
		"name": "Bank"
	}, 
	{
		"id": "128816990522299", 
		"name": "Bank Equipment & Service"
	}, 
	{
		"id": "179702475405145", 
		"name": "Bankruptcy Lawyer"
	}, 
	{
		"id": "199819723365845", 
		"name": "Baptist Church"
	}, 
	{
		"id": "233804719972590", 
		"name": "Bar & Grill"
	}, 
	{
		"id": "150534008338515", 
		"name": "Barbecue Restaurant"
	}, 
	{
		"id": "169758603141095", 
		"name": "Barber Shop"
	}, 
	{
		"id": "191612347546618", 
		"name": "Bartending Service"
	}, 
	{
		"id": "191373750905077", 
		"name": "Basque Restaurant"
	}, 
	{
		"id": "199544366729511", 
		"name": "Batting Cage"
	}, 
	{
		"id": "199165013440146", 
		"name": "Beach"
	}, 
	{
		"id": "199734546726648", 
		"name": "Beach Resort"
	}, 
	{
		"id": "199236533423806", 
		"name": "Beauty Salon"
	}, 
	{
		"id": "110321355709642", 
		"name": "Bed and Breakfast"
	}, 
	{
		"id": "203743122984241", 
		"name": "Beer Garden"
	}, 
	{
		"id": "113581542055311", 
		"name": "Belgian Restaurant"
	}, 
	{
		"id": "209535879087405", 
		"name": "Big Box Retailer"
	}, 
	{
		"id": "433034116710064", 
		"name": "Bike Rental & Bike Share"
	}, 
	{
		"id": "128003127270269", 
		"name": "Bike Shop"
	}, 
	{
		"id": "121321524611296", 
		"name": "Bingo Hall"
	}, 
	{
		"id": "150148928375567", 
		"name": "Biotechnology"
	}, 
	{
		"id": "197154743629294", 
		"name": "Blinds & Curtains"
	}, 
	{
		"id": "186236611410712", 
		"name": "Blood Bank"
	}, 
	{
		"id": "124886030917279", 
		"name": "Boat Dealer"
	}, 
	{
		"id": "170474162998885", 
		"name": "Boat Rental"
	}, 
	{
		"id": "163431627040738", 
		"name": "Boat Service"
	}, 
	{
		"id": "139141179489281", 
		"name": "Boating"
	}, 
	{
		"id": "161467220570897", 
		"name": "Book & Magazine Distribution"
	}, 
	{
		"id": "423120631108780", 
		"name": "Borough"
	}, 
	{
		"id": "182582091788254", 
		"name": "Bowling Alley"
	}, 
	{
		"id": "185459711490789", 
		"name": "Brazilian Restaurant"
	}, 
	{
		"id": "192108214153222", 
		"name": "Breakfast & Brunch Restaurant"
	}, 
	{
		"id": "144535972273084", 
		"name": "Brewery"
	}, 
	{
		"id": "103446129740239", 
		"name": "Bridal Shop"
	}, 
	{
		"id": "151969488199865", 
		"name": "Bridge"
	}, 
	{
		"id": "137670789632630", 
		"name": "British Restaurant"
	}, 
	{
		"id": "169056916473899", 
		"name": "Broadcasting & Media Production"
	}, 
	{
		"id": "143973032336164", 
		"name": "Brokers & Franchising"
	}, 
	{
		"id": "201230299890531", 
		"name": "Buddhist Temple"
	}, 
	{
		"id": "176007949109829", 
		"name": "Buffet Restaurant"
	}, 
	{
		"id": "187425207958280", 
		"name": "Burger Restaurant"
	}, 
	{
		"id": "181108841925391", 
		"name": "Burial & Cremation Service"
	}, 
	{
		"id": "135761909830871", 
		"name": "Burmese Restaurant"
	}, 
	{
		"id": "138456929557798", 
		"name": "Bus Line"
	}, 
	{
		"id": "144386572288836", 
		"name": "Bus Station"
	}, 
	{
		"id": "139745066094977", 
		"name": "Business Center"
	}, 
	{
		"id": "179672275401610", 
		"name": "Business Consultant"
	}, 
	{
		"id": "200209719995975", 
		"name": "Business Supply Service"
	}, 
	{
		"id": "181564868547915", 
		"name": "Butcher"
	}, 
	{
		"id": "213629078651577", 
		"name": "Cabin"
	}, 
	{
		"id": "164274486955790", 
		"name": "Cabinets & Countertops"
	}, 
	{
		"id": "189487254406544", 
		"name": "Cable & Satellite Service"
	}, 
	{
		"id": "197871390225897", 
		"name": "Cafe"
	}, 
	{
		"id": "127892053948220", 
		"name": "Cafeteria"
	}, 
	{
		"id": "154669644591265", 
		"name": "Cajun & Creole Restaurant"
	}, 
	{
		"id": "191232370912538", 
		"name": "Cambodian Restaurant"
	}, 
	{
		"id": "442121929137652", 
		"name": "Camera Store"
	}, 
	{
		"id": "205483332814878", 
		"name": "Camp"
	}, 
	{
		"id": "187004854667366", 
		"name": "Campground"
	}, 
	{
		"id": "216161991738736", 
		"name": "Campus Building"
	}, 
	{
		"id": "202010786573294", 
		"name": "Canadian Restaurant"
	}, 
	{
		"id": "414430838570027", 
		"name": "Candy Store"
	}, 
	{
		"id": "214976388519648", 
		"name": "Cantonese Restaurant"
	}, 
	{
		"id": "131962450204676", 
		"name": "Car Dealership"
	}, 
	{
		"id": "182575511780536", 
		"name": "Car Parts & Accessories"
	}, 
	{
		"id": "198383950173309", 
		"name": "Car Rental"
	}, 
	{
		"id": "162295707155272", 
		"name": "Car Wash & Detailing"
	}, 
	{
		"id": "184395321600410", 
		"name": "Cargo & Freight"
	}, 
	{
		"id": "191765907520539", 
		"name": "Caribbean Restaurant"
	}, 
	{
		"id": "153755631345622", 
		"name": "Carnival Supplies"
	}, 
	{
		"id": "180833545285725", 
		"name": "Carpenter"
	}, 
	{
		"id": "210709755608101", 
		"name": "Carpet Cleaner"
	}, 
	{
		"id": "191328180890797", 
		"name": "Carpet & Flooring Store"
	}, 
	{
		"id": "128197080583700", 
		"name": "Cash Advance Service"
	}, 
	{
		"id": "187724814583579", 
		"name": "Casino"
	}, 
	{
		"id": "139433292785470", 
		"name": "Caterer"
	}, 
	{
		"id": "175647552480085", 
		"name": "Catholic Church"
	}, 
	{
		"id": "191060874251260", 
		"name": "Cemetery"
	}, 
	{
		"id": "181531718550494", 
		"name": "Charismatic Church"
	}, 
	{
		"id": "226326230802065", 
		"name": "Charity Organization"
	}, 
	{
		"id": "108512435893415", 
		"name": "Charter Buses"
	}, 
	{
		"id": "176722429037183", 
		"name": "Cheerleading"
	}, 
	{
		"id": "191334714243008", 
		"name": "Chemicals & Gasses"
	}, 
	{
		"id": "110113695730808", 
		"name": "Chicken Restaurant"
	}, 
	{
		"id": "197767133603296", 
		"name": "Chicken Wings"
	}, 
	{
		"id": "181811248521973", 
		"name": "Child Care"
	}, 
	{
		"id": "162948187091210", 
		"name": "Child Protective Services"
	}, 
	{
		"id": "192614304101075", 
		"name": "Children's Clothing Store"
	}, 
	{
		"id": "174483852595760", 
		"name": "Chinese Restaurant"
	}, 
	{
		"id": "192781160749720", 
		"name": "Chiropractor"
	}, 
	{
		"id": "184266718279692", 
		"name": "Christian Church"
	}, 
	{
		"id": "121659614574801", 
		"name": "Christian Science Church"
	}, 
	{
		"id": "192134360811676", 
		"name": "Church"
	}, 
	{
		"id": "190152457675521", 
		"name": "Church of Christ"
	}, 
	{
		"id": "170386086340798", 
		"name": "Church of God"
	}, 
	{
		"id": "109597022449687", 
		"name": "Church of Jesus Christ of Latter-day Saints"
	}, 
	{
		"id": "213019495381691", 
		"name": "Circus"
	}, 
	{
		"id": "436168419731123", 
		"name": "City Hall"
	}, 
	{
		"id": "280963708658321", 
		"name": "Classes"
	}, 
	{
		"id": "186564191378474", 
		"name": "Cleaning Service"
	}, 
	{
		"id": "193679960660042", 
		"name": "Clergy"
	}, 
	{
		"id": "137847742955715", 
		"name": "Clinic"
	}, 
	{
		"id": "186230924744328", 
		"name": "Clothing Store"
	}, 
	{
		"id": "214668188548441", 
		"name": "Clothing Supply & Distribution"
	}, 
	{
		"id": "186004504854452", 
		"name": "Clubhouse"
	}, 
	{
		"id": "128673187201735", 
		"name": "Coffee Shop"
	}, 
	{
		"id": "187679647929203", 
		"name": "Collectibles Store"
	}, 
	{
		"id": "145008048892483", 
		"name": "Collection Agency"
	}, 
	{
		"id": "108051929285833", 
		"name": "College & University"
	}, 
	{
		"id": "110186619064706", 
		"name": "Comedy Club"
	}, 
	{
		"id": "133510666716809", 
		"name": "Comic Book Store"
	}, 
	{
		"id": "196966680314716", 
		"name": "Commercial Automotive"
	}, 
	{
		"id": "163090273743732", 
		"name": "Commercial Bank"
	}, 
	{
		"id": "243290832429433", 
		"name": "Commercial & Industrial"
	}, 
	{
		"id": "165245226927543", 
		"name": "Commercial & Industrial Equipment"
	}, 
	{
		"id": "162878243763233", 
		"name": "Commercial Real Estate"
	}, 
	{
		"id": "296862927058877", 
		"name": "Community Center"
	}, 
	{
		"id": "152880021441864", 
		"name": "Community Organization"
	}, 
	{
		"id": "108472109230615", 
		"name": "Computer Services"
	}, 
	{
		"id": "199512783398620", 
		"name": "Computer Store"
	}, 
	{
		"id": "162237190493977", 
		"name": "Computer Training"
	}, 
	{
		"id": "139823692748565", 
		"name": "Computers & Electronics"
	}, 
	{
		"id": "179618232079666", 
		"name": "Concrete Contractor"
	}, 
	{
		"id": "200157403331937", 
		"name": "Congregational Church"
	}, 
	{
		"id": "188569091163640", 
		"name": "Construction Service & Supply"
	}, 
	{
		"id": "214297118585256", 
		"name": "Consulate & Embassy"
	}, 
	{
		"id": "197227066968500", 
		"name": "Continental Restaurant"
	}, 
	{
		"id": "124816677590074", 
		"name": "Contractor"
	}, 
	{
		"id": "200253979990258", 
		"name": "Convenience Store"
	}, 
	{
		"id": "139438332785466", 
		"name": "Convent & Monastery"
	}, 
	{
		"id": "134015953331113", 
		"name": "Convention Center"
	}, 
	{
		"id": "182269951819423", 
		"name": "Cooking Lesson"
	}, 
	{
		"id": "205510939478893", 
		"name": "Copying & Printing"
	}, 
	{
		"id": "204787602874500", 
		"name": "Copyright Lawyer"
	}, 
	{
		"id": "197029287003787", 
		"name": "Copywriting Service"
	}, 
	{
		"id": "162479300468980", 
		"name": "Corporate Lawyer"
	}, 
	{
		"id": "152142351517013", 
		"name": "Corporate Office"
	}, 
	{
		"id": "144873802247220", 
		"name": "Cosmetics & Beauty Supply"
	}, 
	{
		"id": "180117982029833", 
		"name": "Costume Shop"
	}, 
	{
		"id": "189006297788323", 
		"name": "Cottage"
	}, 
	{
		"id": "132328993501399", 
		"name": "Counseling & Mental Health"
	}, 
	{
		"id": "355728847806223", 
		"name": "County"
	}, 
	{
		"id": "110121459069433", 
		"name": "Courthouse"
	}, 
	{
		"id": "108443649233212", 
		"name": "Credit Counseling"
	}, 
	{
		"id": "153614521358541", 
		"name": "Criminal Lawyer"
	}, 
	{
		"id": "128568697212195", 
		"name": "Crisis Prevention Center"
	}, 
	{
		"id": "138756772860047", 
		"name": "Crêperie"
	}, 
	{
		"id": "197280796951159", 
		"name": "Cruise"
	}, 
	{
		"id": "139388396125969", 
		"name": "Cruise Excursions"
	}, 
	{
		"id": "192804194073047", 
		"name": "Cuban Restaurant"
	}, 
	{
		"id": "124744617598250", 
		"name": "Culinary School"
	}, 
	{
		"id": "180816211956170", 
		"name": "Cultural Gifts Store"
	}, 
	{
		"id": "325310894151007", 
		"name": "Cupcake Shop"
	}, 
	{
		"id": "189172844438073", 
		"name": "Currency Exchange"
	}, 
	{
		"id": "170353509678476", 
		"name": "Cyber Cafe"
	}, 
	{
		"id": "196285793716152", 
		"name": "Damage Restoration Service"
	}, 
	{
		"id": "176139629103647", 
		"name": "Dance Club"
	}, 
	{
		"id": "203916779633178", 
		"name": "Dance Instruction"
	}, 
	{
		"id": "180781665291519", 
		"name": "Dating Service"
	}, 
	{
		"id": "164595956925901", 
		"name": "Day Care & Preschool"
	}, 
	{
		"id": "205950169432461", 
		"name": "Day Spa"
	}, 
	{
		"id": "166493923398099", 
		"name": "Deck & Patio"
	}, 
	{
		"id": "188334264523313", 
		"name": "Deli"
	}, 
	{
		"id": "132942110106445", 
		"name": "Dental Equipment"
	}, 
	{
		"id": "174187662626299", 
		"name": "Dentist"
	}, 
	{
		"id": "344508555610070", 
		"name": "Department Store"
	}, 
	{
		"id": "196021933757044", 
		"name": "Dermatologist"
	}, 
	{
		"id": "187153754656815", 
		"name": "Dessert Restaurant"
	}, 
	{
		"id": "194588013912896", 
		"name": "Dim Sum Restaurant"
	}, 
	{
		"id": "167954166588517", 
		"name": "Diner"
	}, 
	{
		"id": "137737689633159", 
		"name": "Direct Mail Service"
	}, 
	{
		"id": "189687247721960", 
		"name": "Disability Services"
	}, 
	{
		"id": "188460567855224", 
		"name": "Disabled Persons Services"
	}, 
	{
		"id": "137027063035986", 
		"name": "Disaster Relief"
	}, 
	{
		"id": "183205338384747", 
		"name": "Discount Store"
	}, 
	{
		"id": "162480900474637", 
		"name": "Dive Bar"
	}, 
	{
		"id": "193005947395563", 
		"name": "Divorce & Family Lawyer"
	}, 
	{
		"id": "166419966738430", 
		"name": "DJ"
	}, 
	{
		"id": "192644094099081", 
		"name": "DMV"
	}, 
	{
		"id": "151931054869702", 
		"name": "Document Service"
	}, 
	{
		"id": "175898962454294", 
		"name": "Dog Training"
	}, 
	{
		"id": "201128353243142", 
		"name": "Dog Walker"
	}, 
	{
		"id": "124818864257882", 
		"name": "Donuts & Bagels"
	}, 
	{
		"id": "165665860162999", 
		"name": "Dorm"
	}, 
	{
		"id": "187598571260449", 
		"name": "Drinking Water Distribution"
	}, 
	{
		"id": "188684981153971", 
		"name": "Drive In Restaurant"
	}, 
	{
		"id": "177734062274696", 
		"name": "Driving Range"
	}, 
	{
		"id": "200010220031917", 
		"name": "Driving School"
	}, 
	{
		"id": "186837231348425", 
		"name": "Drug & Alcohol Rehab"
	}, 
	{
		"id": "205776136118265", 
		"name": "Drugstore"
	}, 
	{
		"id": "133148010085253", 
		"name": "Dry Cleaner"
	}, 
	{
		"id": "150432221681325", 
		"name": "DVD & Video Store"
	}, 
	{
		"id": "201201106561123", 
		"name": "Eastern Orthodox Church"
	}, 
	{
		"id": "214416301907154", 
		"name": "Eco Tours"
	}, 
	{
		"id": "152248208162513", 
		"name": "Educational Camp"
	}, 
	{
		"id": "199797140033948", 
		"name": "Educational Consultant"
	}, 
	{
		"id": "187751327923426", 
		"name": "Educational Organization"
	}, 
	{
		"id": "191921914160604", 
		"name": "Educational Research"
	}, 
	{
		"id": "108557642554592", 
		"name": "Educational Service"
	}, 
	{
		"id": "163197293733225", 
		"name": "Educational Supplies"
	}, 
	{
		"id": "199182823425834", 
		"name": "Electrician"
	}, 
	{
		"id": "183430408363083", 
		"name": "Electronic Equipment Service"
	}, 
	{
		"id": "187937741228885", 
		"name": "Electronics Store"
	}, 
	{
		"id": "140234236045713", 
		"name": "Elementary School"
	}, 
	{
		"id": "189040354450145", 
		"name": "Elevator Services"
	}, 
	{
		"id": "206534229374185", 
		"name": "Email Marketing"
	}, 
	{
		"id": "154067984646918", 
		"name": "Emergency Roadside Service"
	}, 
	{
		"id": "145685118824723", 
		"name": "Emissions Inspection"
	}, 
	{
		"id": "124814294258910", 
		"name": "Employment Agency"
	}, 
	{
		"id": "189541204423829", 
		"name": "Employment Lawyer"
	}, 
	{
		"id": "400062273344681", 
		"name": "Engineering Service"
	}, 
	{
		"id": "169925186386431", 
		"name": "Entertainment Service"
	}, 
	{
		"id": "191523214199822", 
		"name": "Environmental Conservation"
	}, 
	{
		"id": "128268517241197", 
		"name": "Environmental Consultant"
	}, 
	{
		"id": "170721982973337", 
		"name": "Episcopal Church"
	}, 
	{
		"id": "182706848434579", 
		"name": "Equipment Service & Supply"
	}, 
	{
		"id": "161558893893842", 
		"name": "Escrow Services"
	}, 
	{
		"id": "121688031239297", 
		"name": "Estate Lawyer"
	}, 
	{
		"id": "204887546203055", 
		"name": "Estate Planning"
	}, 
	{
		"id": "146053955462002", 
		"name": "Esthethics"
	}, 
	{
		"id": "205689066126145", 
		"name": "Ethiopian Restaurant"
	}, 
	{
		"id": "144815382251809", 
		"name": "Ethnic Grocery Store"
	}, 
	{
		"id": "108447855899758", 
		"name": "Evangelical Church"
	}, 
	{
		"id": "187443774619522", 
		"name": "Event Planner"
	}, 
	{
		"id": "211155112228091", 
		"name": "Event Venue"
	}, 
	{
		"id": "196639807029364", 
		"name": "Excavation & Wrecking"
	}, 
	{
		"id": "188159097871782", 
		"name": "Exchange Program"
	}, 
	{
		"id": "198551986844046", 
		"name": "Exotic Car Rental"
	}, 
	{
		"id": "133472970051251", 
		"name": "Eyewear"
	}, 
	{
		"id": "162648480454674", 
		"name": "Fairground"
	}, 
	{
		"id": "113914582020990", 
		"name": "Family Doctor"
	}, 
	{
		"id": "144657392262041", 
		"name": "Family Medicine Practice"
	}, 
	{
		"id": "192831537402299", 
		"name": "Family Style Restaurant"
	}, 
	{
		"id": "150815208309028", 
		"name": "Farm"
	}, 
	{
		"id": "176527262444235", 
		"name": "Farmers Market"
	}, 
	{
		"id": "179576078750378", 
		"name": "Fashion Designer"
	}, 
	{
		"id": "192803624072087", 
		"name": "Fast Food Restaurant"
	}, 
	{
		"id": "199830500030940", 
		"name": "Ferry & Boat"
	}, 
	{
		"id": "107287559351594", 
		"name": "Filipino Restaurant"
	}, 
	{
		"id": "114047665342448", 
		"name": "Financial Aid"
	}, 
	{
		"id": "211381282212118", 
		"name": "Financial Planning"
	}, 
	{
		"id": "181289228581329", 
		"name": "Fine Dining Restaurant"
	}, 
	{
		"id": "197796476897760", 
		"name": "Fire Protection"
	}, 
	{
		"id": "150681761655205", 
		"name": "Fire Station"
	}, 
	{
		"id": "124620910942599", 
		"name": "Fireplaces"
	}, 
	{
		"id": "193339160684487", 
		"name": "Fireproofing"
	}, 
	{
		"id": "196493330361697", 
		"name": "Fireworks Retailer"
	}, 
	{
		"id": "185032388204011", 
		"name": "First Aid Class"
	}, 
	{
		"id": "201034006586500", 
		"name": "First Aid Service"
	}, 
	{
		"id": "167608369957681", 
		"name": "Fish & Chips Shop"
	}, 
	{
		"id": "110098282406681", 
		"name": "Fishing"
	}, 
	{
		"id": "191681657527859", 
		"name": "Fitness Center"
	}, 
	{
		"id": "179278362129856", 
		"name": "Flea Market"
	}, 
	{
		"id": "192111490806699", 
		"name": "Florist"
	}, 
	{
		"id": "167116956674095", 
		"name": "Fondue Restaurant"
	}, 
	{
		"id": "200019523363001", 
		"name": "Food & Beverage Service & Distribution"
	}, 
	{
		"id": "175962259115742", 
		"name": "Food & Beverage Service & Distribution"
	}, 
	{
		"id": "187462324610381", 
		"name": "Food Consultant"
	}, 
	{
		"id": "144362285623268", 
		"name": "Food Stand"
	}, 
	{
		"id": "224426430990363", 
		"name": "Food Truck"
	}, 
	{
		"id": "121405177935134", 
		"name": "Forestry & Logging"
	}, 
	{
		"id": "149966661728482", 
		"name": "Formal Wear"
	}, 
	{
		"id": "182923418412354", 
		"name": "Franchising Service"
	}, 
	{
		"id": "168976549819329", 
		"name": "French Restaurant"
	}, 
	{
		"id": "215290398491661", 
		"name": "Frozen Yogurt Shop"
	}, 
	{
		"id": "128157407253652", 
		"name": "Fruit & Vegetable Store"
	}, 
	{
		"id": "127410733993761", 
		"name": "Full Gospel Church"
	}, 
	{
		"id": "177892565587583", 
		"name": "Funeral Service"
	}, 
	{
		"id": "187813774574368", 
		"name": "Furniture Repair"
	}, 
	{
		"id": "162845797101278", 
		"name": "Furniture Store"
	}, 
	{
		"id": "199850580046875", 
		"name": "Garage Door Services"
	}, 
	{
		"id": "193271047368648", 
		"name": "Garden Center"
	}, 
	{
		"id": "156555961070638", 
		"name": "Gardener"
	}, 
	{
		"id": "165531376827271", 
		"name": "Gas & Chemical Service"
	}, 
	{
		"id": "139272729470823", 
		"name": "Gas Station"
	}, 
	{
		"id": "164049010316507", 
		"name": "Gastropub"
	}, 
	{
		"id": "128470943900600", 
		"name": "Gay Bar"
	}, 
	{
		"id": "200531149962145", 
		"name": "Genealogist"
	}, 
	{
		"id": "194021237293565", 
		"name": "Geologic Service"
	}, 
	{
		"id": "150217168372274", 
		"name": "German Restaurant"
	}, 
	{
		"id": "191647907538150", 
		"name": "Gift Shop"
	}, 
	{
		"id": "127781400626024", 
		"name": "Glass Products"
	}, 
	{
		"id": "199562100074695", 
		"name": "Glass Service"
	}, 
	{
		"id": "155358844524028", 
		"name": "Gluten-Free Restaurant"
	}, 
	{
		"id": "235437449807086", 
		"name": "Go Karting"
	}, 
	{
		"id": "176059775772759", 
		"name": "Golf Course"
	}, 
	{
		"id": "161422927240513", 
		"name": "Government Organization"
	}, 
	{
		"id": "110245495716786", 
		"name": "Governmental Law"
	}, 
	{
		"id": "162183907165552", 
		"name": "Graphic Design"
	}, 
	{
		"id": "144722595590046", 
		"name": "Greek Restaurant"
	}, 
	{
		"id": "169207329791658", 
		"name": "Grocery Store"
	}, 
	{
		"id": "152275908161439", 
		"name": "Gun Range"
	}, 
	{
		"id": "180302115349257", 
		"name": "Gun Store"
	}, 
	{
		"id": "184405378265823", 
		"name": "Gym"
	}, 
	{
		"id": "191693100854505", 
		"name": "Hair & Beauty Supply"
	}, 
	{
		"id": "128905757179140", 
		"name": "Hair Removal"
	}, 
	{
		"id": "188339094522319", 
		"name": "Hair Replacement"
	}, 
	{
		"id": "174177802634376", 
		"name": "Hair Salon"
	}, 
	{
		"id": "181550638549454", 
		"name": "Hairpieces & Extensions"
	}, 
	{
		"id": "193694197335994", 
		"name": "Halal Restaurant"
	}, 
	{
		"id": "121781067897279", 
		"name": "Halfway House"
	}, 
	{
		"id": "144502665609043", 
		"name": "Handwriting Service"
	}, 
	{
		"id": "148906328500868", 
		"name": "Hardware Store"
	}, 
	{
		"id": "169026306477520", 
		"name": "Hardware & Tools Service"
	}, 
	{
		"id": "191876627510158", 
		"name": "Hawaiian Restaurant"
	}, 
	{
		"id": "134091706658568", 
		"name": "Health Agency"
	}, 
	{
		"id": "128282540573946", 
		"name": "Health Care Administration"
	}, 
	{
		"id": "156756251046858", 
		"name": "Health Food Restaurant"
	}, 
	{
		"id": "198722103478014", 
		"name": "Health Food Store"
	}, 
	{
		"id": "211987392145473", 
		"name": "Health Spa"
	}, 
	{
		"id": "175272389190311", 
		"name": "Healthcare Administrator"
	}, 
	{
		"id": "132219350176698", 
		"name": "Heating, Ventilating & Air Conditioning"
	}, 
	{
		"id": "110152272401235", 
		"name": "High School"
	}, 
	{
		"id": "214332375266411", 
		"name": "Highway"
	}, 
	{
		"id": "135660879839870", 
		"name": "Himalayan Restaurant"
	}, 
	{
		"id": "587075671302634", 
		"name": "Hindu Temple"
	}, 
	{
		"id": "197097220301977", 
		"name": "Historical Place"
	}, 
	{
		"id": "244600818962350", 
		"name": "History Museum"
	}, 
	{
		"id": "201207006556711", 
		"name": "Holiness Church"
	}, 
	{
		"id": "197289820310880", 
		"name": "Home"
	}, 
	{
		"id": "157320344328906", 
		"name": "Home Cleaning"
	}, 
	{
		"id": "128784863859103", 
		"name": "Home Inspection"
	}, 
	{
		"id": "150590361670906", 
		"name": "Home Security"
	}, 
	{
		"id": "145925682134541", 
		"name": "Home Theater Store"
	}, 
	{
		"id": "162645523784869", 
		"name": "Home Window Service"
	}, 
	{
		"id": "223801560977980", 
		"name": "Hookah Lounge"
	}, 
	{
		"id": "180588421978578", 
		"name": "Horse-Drawn Vehicles"
	}, 
	{
		"id": "181108811925394", 
		"name": "Horses"
	}, 
	{
		"id": "133152263416981", 
		"name": "Hospital"
	}, 
	{
		"id": "180699075298665", 
		"name": "Hospitality Service"
	}, 
	{
		"id": "150438461681329", 
		"name": "Hostel"
	}, 
	{
		"id": "177756732269376", 
		"name": "Hot Air Balloons"
	}, 
	{
		"id": "212285478786733", 
		"name": "Hot Dog Joint"
	}, 
	{
		"id": "207101895984270", 
		"name": "Hot Dog Stand"
	}, 
	{
		"id": "199788206699825", 
		"name": "Hotel Supply Service"
	}, 
	{
		"id": "189771787733424", 
		"name": "House Sitter"
	}, 
	{
		"id": "183680385005847", 
		"name": "Housewares"
	}, 
	{
		"id": "114055392008299", 
		"name": "Housing Assistance Service"
	}, 
	{
		"id": "124622240942151", 
		"name": "Housing & Homeless Shelter"
	}, 
	{
		"id": "185368671504202", 
		"name": "Hungarian Restaurant"
	}, 
	{
		"id": "175333089178368", 
		"name": "Hunting and Fishing"
	}, 
	{
		"id": "200863816597800", 
		"name": "Ice Cream Parlor"
	}, 
	{
		"id": "166339023413399", 
		"name": "Ice Machines"
	}, 
	{
		"id": "129327030469234", 
		"name": "Ice Skating"
	}, 
	{
		"id": "132008380200065", 
		"name": "Image Consultant"
	}, 
	{
		"id": "188625341157848", 
		"name": "Independent Church"
	}, 
	{
		"id": "129539913784760", 
		"name": "Indian Restaurant"
	}, 
	{
		"id": "167749593275424", 
		"name": "Indonesian Restaurant"
	}, 
	{
		"id": "181803978524025", 
		"name": "Inn"
	}, 
	{
		"id": "152339818172592", 
		"name": "Insurance Agent"
	}, 
	{
		"id": "109594239116608", 
		"name": "Insurance Broker"
	}, 
	{
		"id": "198883503460766", 
		"name": "Interdenominational Church"
	}, 
	{
		"id": "199438050070864", 
		"name": "Interior Designer"
	}, 
	{
		"id": "132227236842772", 
		"name": "Internal Medicine"
	}, 
	{
		"id": "156227661101293", 
		"name": "International Restaurant"
	}, 
	{
		"id": "201035296584114", 
		"name": "Internet Cafe"
	}, 
	{
		"id": "187215161312096", 
		"name": "Internet Service Provider"
	}, 
	{
		"id": "190690290956124", 
		"name": "Inventory Control Service"
	}, 
	{
		"id": "213577718658733", 
		"name": "Investing Service"
	}, 
	{
		"id": "137463256320813", 
		"name": "Irish Restaurant"
	}, 
	{
		"id": "193831710644458", 
		"name": "Italian Restaurant"
	}, 
	{
		"id": "190108547677820", 
		"name": "Janitorial Service"
	}, 
	{
		"id": "199035016778342", 
		"name": "Japanese Restaurant"
	}, 
	{
		"id": "207290352633942", 
		"name": "Jazz Club"
	}, 
	{
		"id": "188031587886173", 
		"name": "Jewelry Store"
	}, 
	{
		"id": "155851681143483", 
		"name": "Jewelry Supplier"
	}, 
	{
		"id": "181363338568345", 
		"name": "Juvenile Law"
	}, 
	{
		"id": "187872604591327", 
		"name": "Karaoke"
	}, 
	{
		"id": "189702521054390", 
		"name": "Kennel"
	}, 
	{
		"id": "187677931267173", 
		"name": "Kingdom Hall"
	}, 
	{
		"id": "209904849035077", 
		"name": "Kitchen Construction"
	}, 
	{
		"id": "150896171638138", 
		"name": "Korean Restaurant"
	}, 
	{
		"id": "205628702786662", 
		"name": "Kosher Restaurant"
	}, 
	{
		"id": "198532213496709", 
		"name": "Labor & Employment Law"
	}, 
	{
		"id": "144810842247435", 
		"name": "Laboratory Equipment"
	}, 
	{
		"id": "128853933850116", 
		"name": "Landscaping"
	}, 
	{
		"id": "191533400865548", 
		"name": "Language School"
	}, 
	{
		"id": "210460678964858", 
		"name": "Laser Hair Removal"
	}, 
	{
		"id": "232085443469192", 
		"name": "Laser Tag"
	}, 
	{
		"id": "171466272901863", 
		"name": "Late Night Restaurant"
	}, 
	{
		"id": "192242714144170", 
		"name": "Latin American Restaurant"
	}, 
	{
		"id": "286280034782160", 
		"name": "Laundromat"
	}, 
	{
		"id": "153297678056879", 
		"name": "Law Enforcement"
	}, 
	{
		"id": "189806667707056", 
		"name": "Law Practice"
	}, 
	{
		"id": "205479252799194", 
		"name": "Lebanese Restaurant"
	}, 
	{
		"id": "360320934014496", 
		"name": "Lifestyle Services"
	}, 
	{
		"id": "196820813663200", 
		"name": "Lighting Fixtures"
	}, 
	{
		"id": "196941987012177", 
		"name": "Limo Service"
	}, 
	{
		"id": "199833073363963", 
		"name": "Liquor Store"
	}, 
	{
		"id": "204867426208613", 
		"name": "Live & Raw Food Restaurant"
	}, 
	{
		"id": "128184253916402", 
		"name": "Loans"
	}, 
	{
		"id": "185881398118852", 
		"name": "Lobbyist"
	}, 
	{
		"id": "215089838505460", 
		"name": "Local Education"
	}, 
	{
		"id": "181814521855864", 
		"name": "Locksmith"
	}, 
	{
		"id": "199611383389617", 
		"name": "Lodge"
	}, 
	{
		"id": "198170790193825", 
		"name": "Lottery Retailer"
	}, 
	{
		"id": "135930436481618", 
		"name": "Lounge"
	}, 
	{
		"id": "177492522293723", 
		"name": "Luggage Service"
	}, 
	{
		"id": "139462872784035", 
		"name": "Lutheran Church"
	}, 
	{
		"id": "110351045706277", 
		"name": "Maid & Butler"
	}, 
	{
		"id": "146059155460366", 
		"name": "Makeup Artist"
	}, 
	{
		"id": "198383150193535", 
		"name": "Malaysian Restaurant"
	}, 
	{
		"id": "132778023455109", 
		"name": "Malpractice Law"
	}, 
	{
		"id": "201528873201605", 
		"name": "Management Service"
	}, 
	{
		"id": "178048968909016", 
		"name": "Manufacturing"
	}, 
	{
		"id": "197251360301109", 
		"name": "Marina"
	}, 
	{
		"id": "114253171987086", 
		"name": "Marine Equipment"
	}, 
	{
		"id": "132948550106442", 
		"name": "Marine Service Station"
	}, 
	{
		"id": "162813670434541", 
		"name": "Market"
	}, 
	{
		"id": "152088421520086", 
		"name": "Market Research Consultant"
	}, 
	{
		"id": "170992992946914", 
		"name": "Marketing Consultant"
	}, 
	{
		"id": "198325860180715", 
		"name": "Martial Arts"
	}, 
	{
		"id": "124555004283973", 
		"name": "Masonry"
	}, 
	{
		"id": "109578329118821", 
		"name": "Massage"
	}, 
	{
		"id": "203842589633696", 
		"name": "Mattress Manufacturing"
	}, 
	{
		"id": "132452193487149", 
		"name": "Mattress Wholesale"
	}, 
	{
		"id": "191990114153751", 
		"name": "Mattresses & Bedding"
	}, 
	{
		"id": "182190828486727", 
		"name": "Meat Shop"
	}, 
	{
		"id": "228143393877753", 
		"name": "Medical Center"
	}, 
	{
		"id": "175733465812134", 
		"name": "Medical Equipment"
	}, 
	{
		"id": "186546178044573", 
		"name": "Medical Lab"
	}, 
	{
		"id": "180931928610132", 
		"name": "Medical Research"
	}, 
	{
		"id": "190153097675457", 
		"name": "Medical School"
	}, 
	{
		"id": "203654586323143", 
		"name": "Medical Spa"
	}, 
	{
		"id": "124907487582838", 
		"name": "Medical Supplies"
	}, 
	{
		"id": "176960322351733", 
		"name": "Mediterranean Restaurant"
	}, 
	{
		"id": "210261102322291", 
		"name": "Meeting Room"
	}, 
	{
		"id": "192157707478469", 
		"name": "Mennonite Church"
	}, 
	{
		"id": "170241263022353", 
		"name": "Men's Clothing Store"
	}, 
	{
		"id": "169363643109176", 
		"name": "Merchandising Service"
	}, 
	{
		"id": "182387268467261", 
		"name": "Metals"
	}, 
	{
		"id": "193064780713408", 
		"name": "Methodist Church"
	}, 
	{
		"id": "199377230079198", 
		"name": "Mexican Restaurant"
	}, 
	{
		"id": "167885889930008", 
		"name": "Middle Eastern Restaurant"
	}, 
	{
		"id": "220974118003804", 
		"name": "Military Base"
	}, 
	{
		"id": "145250718867825", 
		"name": "Miniature Golf"
	}, 
	{
		"id": "196547683690201", 
		"name": "Mission"
	}, 
	{
		"id": "190189837667432", 
		"name": "Mobile Homes"
	}, 
	{
		"id": "210979565595898", 
		"name": "Mobile Phone Shop"
	}, 
	{
		"id": "188763924479267", 
		"name": "Modeling Agency"
	}, 
	{
		"id": "378970035464823", 
		"name": "Modern Art Museum"
	}, 
	{
		"id": "188360891207745", 
		"name": "Modern European Restaurant"
	}, 
	{
		"id": "151195168276371", 
		"name": "Mongolian Restaurant"
	}, 
	{
		"id": "276651312419490", 
		"name": "Monument"
	}, 
	{
		"id": "191073970923905", 
		"name": "Moroccan Restaurant"
	}, 
	{
		"id": "136191809788079", 
		"name": "Mortgage Brokers"
	}, 
	{
		"id": "179905035385252", 
		"name": "Mosque"
	}, 
	{
		"id": "152050108191372", 
		"name": "Motel"
	}, 
	{
		"id": "108287585916424", 
		"name": "Motorcycle Repair"
	}, 
	{
		"id": "150820404974203", 
		"name": "Motorcycles"
	}, 
	{
		"id": "214854141863792", 
		"name": "Mountain Biking"
	}, 
	{
		"id": "185880521445708", 
		"name": "Mover"
	}, 
	{
		"id": "370369022981015", 
		"name": "Movie & Television Studio"
	}, 
	{
		"id": "192511100766680", 
		"name": "Movie Theatre"
	}, 
	{
		"id": "186983191324114", 
		"name": "Music Lessons & Instruction"
	}, 
	{
		"id": "189483194405517", 
		"name": "Music Production"
	}, 
	{
		"id": "396255327112122", 
		"name": "Music Store"
	}, 
	{
		"id": "139750396088115", 
		"name": "Musical Instrument Store"
	}, 
	{
		"id": "198516863494646", 
		"name": "Nail Salon"
	}, 
	{
		"id": "114044592008363", 
		"name": "Nanny"
	}, 
	{
		"id": "205359639482698", 
		"name": "National Park"
	}, 
	{
		"id": "149452815111438", 
		"name": "Nazarene Church"
	}, 
	{
		"id": "186869748024304", 
		"name": "Nepalese Restaurant"
	}, 
	{
		"id": "110107385737667", 
		"name": "New American Restaurant"
	}, 
	{
		"id": "191478144212980", 
		"name": "Night Club"
	}, 
	{
		"id": "354275401259620", 
		"name": "Nightlife"
	}, 
	{
		"id": "200639493285676", 
		"name": "Nondenominational Church"
	}, 
	{
		"id": "108459679231422", 
		"name": "Notary Public"
	}, 
	{
		"id": "182360455136767", 
		"name": "Nursing"
	}, 
	{
		"id": "183037088401331", 
		"name": "Nursing Home"
	}, 
	{
		"id": "197995016883073", 
		"name": "Nutritionist"
	}, 
	{
		"id": "127772663958428", 
		"name": "OBGYN"
	}, 
	{
		"id": "199383530078300", 
		"name": "Occupational Safety"
	}, 
	{
		"id": "170598252986387", 
		"name": "Occupational Therapist"
	}, 
	{
		"id": "215492291888288", 
		"name": "Ocean"
	}, 
	{
		"id": "196357563722974", 
		"name": "Oil Lube & Filter Service"
	}, 
	{
		"id": "162203750496209", 
		"name": "Oncologist"
	}, 
	{
		"id": "200279126653253", 
		"name": "Ophthalmologist"
	}, 
	{
		"id": "192316870798061", 
		"name": "Optometrist"
	}, 
	{
		"id": "103436486409265", 
		"name": "Orchestra"
	}, 
	{
		"id": "198503866828628", 
		"name": "Organization"
	}, 
	{
		"id": "145117552216056", 
		"name": "Otolaryngologist"
	}, 
	{
		"id": "153490828039067", 
		"name": "Outdoor Equipment Store"
	}, 
	{
		"id": "139721016091877", 
		"name": "Outdoor Recreation"
	}, 
	{
		"id": "340406299360512", 
		"name": "Outdoor Services"
	}, 
	{
		"id": "272705352802676", 
		"name": "Outdoors"
	}, 
	{
		"id": "128698093865240", 
		"name": "Outlet Store"
	}, 
	{
		"id": "124999390906893", 
		"name": "Packaging Supplies & Equipment"
	}, 
	{
		"id": "171432846236153", 
		"name": "Paintball"
	}, 
	{
		"id": "177645802278169", 
		"name": "Painter"
	}, 
	{
		"id": "207484765932960", 
		"name": "Pakistani Restaurant"
	}, 
	{
		"id": "115090141929327", 
		"name": "Park"
	}, 
	{
		"id": "200027430011994", 
		"name": "Parking"
	}, 
	{
		"id": "189334414420898", 
		"name": "Party Center"
	}, 
	{
		"id": "109633322446882", 
		"name": "Party Supplies"
	}, 
	{
		"id": "149044025154029", 
		"name": "Passport & Visa Service"
	}, 
	{
		"id": "166582800055512", 
		"name": "Patent Trademark & Copyright Law"
	}, 
	{
		"id": "110218445719092", 
		"name": "Patrol & Security"
	}, 
	{
		"id": "188977087789280", 
		"name": "Paving & Asphalt Service"
	}, 
	{
		"id": "284922938257468", 
		"name": "Pawn Shop"
	}, 
	{
		"id": "191325380891389", 
		"name": "Pawn Shop"
	}, 
	{
		"id": "132003726865268", 
		"name": "Pediatrics"
	}, 
	{
		"id": "177900302253752", 
		"name": "Pentecostal Church"
	}, 
	{
		"id": "210881938937928", 
		"name": "Performance Venue"
	}, 
	{
		"id": "187301137968148", 
		"name": "Performing Arts Education"
	}, 
	{
		"id": "109377152477621", 
		"name": "Persian Restaurant"
	}, 
	{
		"id": "185900881450649", 
		"name": "Personal Coaching"
	}, 
	{
		"id": "181045748599578", 
		"name": "Personal Trainer"
	}, 
	{
		"id": "137420212991446", 
		"name": "Peruvian Restaurant"
	}, 
	{
		"id": "177939525582614", 
		"name": "Pest Control"
	}, 
	{
		"id": "140154442713316", 
		"name": "Pet Breeder"
	}, 
	{
		"id": "179692792071824", 
		"name": "Pet Cemetery"
	}, 
	{
		"id": "163003840417682", 
		"name": "Pet Groomer"
	}, 
	{
		"id": "208287852530384", 
		"name": "Pet Sitter"
	}, 
	{
		"id": "188573091164316", 
		"name": "Pet Store"
	}, 
	{
		"id": "193508567343323", 
		"name": "Petroleum Services"
	}, 
	{
		"id": "186911214686518", 
		"name": "Petting Zoo"
	}, 
	{
		"id": "134381433294944", 
		"name": "Pharmacy"
	}, 
	{
		"id": "211063415594061", 
		"name": "Pho Restaurant"
	}, 
	{
		"id": "191969860827280", 
		"name": "Photographic Services & Equipment"
	}, 
	{
		"id": "109615542448700", 
		"name": "Physical Fitness"
	}, 
	{
		"id": "181885068517499", 
		"name": "Physical Therapist"
	}, 
	{
		"id": "124706954268810", 
		"name": "Physician Assistant"
	}, 
	{
		"id": "200597389954350", 
		"name": "Picnic Ground"
	}, 
	{
		"id": "180256082015845", 
		"name": "Pizza Place"
	}, 
	{
		"id": "188780244476392", 
		"name": "Plastic Surgery"
	}, 
	{
		"id": "145002912227813", 
		"name": "Plastics"
	}, 
	{
		"id": "192092574152128", 
		"name": "Playground"
	}, 
	{
		"id": "178867352155084", 
		"name": "Plumber"
	}, 
	{
		"id": "190310404327530", 
		"name": "Podiatrist"
	}, 
	{
		"id": "200121186665577", 
		"name": "Police Station"
	}, 
	{
		"id": "150805268316547", 
		"name": "Polish Restaurant"
	}, 
	{
		"id": "373543049350668", 
		"name": "Political Organization"
	}, 
	{
		"id": "201159503244240", 
		"name": "Polynesian Restaurant"
	}, 
	{
		"id": "197750126917541", 
		"name": "Pool & Billiards"
	}, 
	{
		"id": "350040338394916", 
		"name": "Port"
	}, 
	{
		"id": "180720568631853", 
		"name": "Portable Building Service"
	}, 
	{
		"id": "133886996679184", 
		"name": "Portable Toilet Rentals"
	}, 
	{
		"id": "155167537873297", 
		"name": "Portuguese Restaurant"
	}, 
	{
		"id": "175838732461622", 
		"name": "Post Office"
	}, 
	{
		"id": "166443590070313", 
		"name": "Pregnancy & Childbirth Service"
	}, 
	{
		"id": "152783908110257", 
		"name": "Presbyterian Church"
	}, 
	{
		"id": "180551801986954", 
		"name": "Preschool"
	}, 
	{
		"id": "197888373555475", 
		"name": "Printing Service"
	}, 
	{
		"id": "270971946329420", 
		"name": "Prison & Correctional Facility"
	}, 
	{
		"id": "192985434070895", 
		"name": "Private Investigator"
	}, 
	{
		"id": "187495294614939", 
		"name": "Private Plane Charter"
	}, 
	{
		"id": "186998168001766", 
		"name": "Private School"
	}, 
	{
		"id": "333158986749730", 
		"name": "Private Transportation"
	}, 
	{
		"id": "200263853339159", 
		"name": "Promotional Item Services"
	}, 
	{
		"id": "199832016699296", 
		"name": "Property Law"
	}, 
	{
		"id": "124701514268099", 
		"name": "Property Management"
	}, 
	{
		"id": "108565442553819", 
		"name": "Psychic"
	}, 
	{
		"id": "206714069358248", 
		"name": "Psychologist"
	}, 
	{
		"id": "218693881483234", 
		"name": "Pub"
	}, 
	{
		"id": "192021210817573", 
		"name": "Public Relations"
	}, 
	{
		"id": "199405806739848", 
		"name": "Public School"
	}, 
	{
		"id": "139386576124160", 
		"name": "Public Services"
	}, 
	{
		"id": "110207655727714", 
		"name": "Public Square"
	}, 
	{
		"id": "133749773359552", 
		"name": "Public Transportation"
	}, 
	{
		"id": "436846369665656", 
		"name": "Public Utility"
	}, 
	{
		"id": "196083133750448", 
		"name": "Race Cars"
	}, 
	{
		"id": "193257397369585", 
		"name": "Race Track"
	}, 
	{
		"id": "189799921044604", 
		"name": "Racquetball Court"
	}, 
	{
		"id": "198121916870488", 
		"name": "Radio & Communication Equipment"
	}, 
	{
		"id": "182486161790013", 
		"name": "Rafting"
	}, 
	{
		"id": "108376755907313", 
		"name": "Railroad"
	}, 
	{
		"id": "218838724804749", 
		"name": "Ramen Restaurant"
	}, 
	{
		"id": "196739023685716", 
		"name": "Real Estate Agent"
	}, 
	{
		"id": "199632896715139", 
		"name": "Real Estate Appraiser"
	}, 
	{
		"id": "162532913805106", 
		"name": "Real Estate Developer"
	}, 
	{
		"id": "150944301629503", 
		"name": "Real Estate Investment"
	}, 
	{
		"id": "187716201260376", 
		"name": "Real Estate Lawyer"
	}, 
	{
		"id": "192625037432720", 
		"name": "Real Estate Service"
	}, 
	{
		"id": "145208072207332", 
		"name": "Real Estate Title & Development"
	}, 
	{
		"id": "183013211744255", 
		"name": "Recreation Center"
	}, 
	{
		"id": "154585851262816", 
		"name": "Recreation Center"
	}, 
	{
		"id": "124698237604010", 
		"name": "Recreational Vehicle Dealer"
	}, 
	{
		"id": "124736910930693", 
		"name": "Recruiter"
	}, 
	{
		"id": "190648534311833", 
		"name": "Recycling & Waste Management"
	}, 
	{
		"id": "200974513251108", 
		"name": "Recycling & Waste Management"
	}, 
	{
		"id": "124547594285513", 
		"name": "Refrigeration"
	}, 
	{
		"id": "103479803071590", 
		"name": "Refrigeration Sales & Service"
	}, 
	{
		"id": "115725465228008", 
		"name": "Region"
	}, 
	{
		"id": "201787963175866", 
		"name": "Religious Book Store"
	}, 
	{
		"id": "187714557925874", 
		"name": "Religious Organization"
	}, 
	{
		"id": "193128447381850", 
		"name": "Religious School"
	}, 
	{
		"id": "200106420005165", 
		"name": "Rent to Own Store"
	}, 
	{
		"id": "124402857692349", 
		"name": "Rental Company"
	}, 
	{
		"id": "162758110442965", 
		"name": "Rental Shop"
	}, 
	{
		"id": "193198380699462", 
		"name": "Repair Service"
	}, 
	{
		"id": "128421653893948", 
		"name": "Reproductive Services"
	}, 
	{
		"id": "108470879231339", 
		"name": "Research Service"
	}, 
	{
		"id": "317580934980424", 
		"name": "Reservoir"
	}, 
	{
		"id": "187686707929197", 
		"name": "Resort"
	}, 
	{
		"id": "197260276952187", 
		"name": "Restaurant Supply"
	}, 
	{
		"id": "191334337551378", 
		"name": "Restaurant Wholesale"
	}, 
	{
		"id": "162920420424772", 
		"name": "Retirement & Assisted Living Facility"
	}, 
	{
		"id": "292231357479999", 
		"name": "Robotics"
	}, 
	{
		"id": "174921992560086", 
		"name": "Rock Climbing"
	}, 
	{
		"id": "197524766940938", 
		"name": "Rodeo"
	}, 
	{
		"id": "210659552293602", 
		"name": "Roller Coaster"
	}, 
	{
		"id": "206284062724685", 
		"name": "Roofer"
	}, 
	{
		"id": "193077897388949", 
		"name": "Rubber Service & Supply"
	}, 
	{
		"id": "157978694256306", 
		"name": "Russian Restaurant"
	}, 
	{
		"id": "110280495719821", 
		"name": "RV Dealership"
	}, 
	{
		"id": "204359242921685", 
		"name": "RV Park"
	}, 
	{
		"id": "186657301367693", 
		"name": "RV Repair"
	}, 
	{
		"id": "181679458534697", 
		"name": "Safety & First Aid Service"
	}, 
	{
		"id": "112286315572975", 
		"name": "Salad Bar"
	}, 
	{
		"id": "191802827505188", 
		"name": "Salvation Army"
	}, 
	{
		"id": "188296324525457", 
		"name": "Sandwich Shop"
	}, 
	{
		"id": "191654867538088", 
		"name": "Scandinavian Restaurant"
	}, 
	{
		"id": "190592477648673", 
		"name": "School Fundraiser"
	}, 
	{
		"id": "191373470890862", 
		"name": "School Transportation"
	}, 
	{
		"id": "211125172246436", 
		"name": "Scooter Rental"
	}, 
	{
		"id": "139197659476308", 
		"name": "Screen Printing & Embroidery"
	}, 
	{
		"id": "169706939742581", 
		"name": "Scuba Diving"
	}, 
	{
		"id": "163300367054197", 
		"name": "Seafood Restaurant"
	}, 
	{
		"id": "180354032000162", 
		"name": "Seasonal Store"
	}, 
	{
		"id": "134312329967620", 
		"name": "Secretarial Service"
	}, 
	{
		"id": "133354270064406", 
		"name": "Security"
	}, 
	{
		"id": "124668097604494", 
		"name": "Senior Center"
	}, 
	{
		"id": "140264492710151", 
		"name": "Septic Tank Service"
	}, 
	{
		"id": "133137800086828", 
		"name": "Septic Tank Service"
	}, 
	{
		"id": "145218608873472", 
		"name": "Service Station Supply"
	}, 
	{
		"id": "187333341297290", 
		"name": "Seventh Day Adventist Church"
	}, 
	{
		"id": "192308454131801", 
		"name": "Sewer Service"
	}, 
	{
		"id": "140784189318631", 
		"name": "Sewing & Seamstress"
	}, 
	{
		"id": "109512302457693", 
		"name": "Shoe Store"
	}, 
	{
		"id": "136412456432179", 
		"name": "Shopping District"
	}, 
	{
		"id": "109527622457518", 
		"name": "Shopping Mall"
	}, 
	{
		"id": "200046713342752", 
		"name": "Shopping Service"
	}, 
	{
		"id": "188953757794108", 
		"name": "Signs & Banner Service"
	}, 
	{
		"id": "367259453311239", 
		"name": "Sikh Temple"
	}, 
	{
		"id": "142590562472824", 
		"name": "Singaporean Restaurant"
	}, 
	{
		"id": "162841010432730", 
		"name": "Ski Resort"
	}, 
	{
		"id": "144087115657937", 
		"name": "Ski & Snowboard School"
	}, 
	{
		"id": "138322342904312", 
		"name": "Skin Care"
	}, 
	{
		"id": "176803072363608", 
		"name": "Sky Diving"
	}, 
	{
		"id": "144810402253538", 
		"name": "Smog Check Station"
	}, 
	{
		"id": "219222658110242", 
		"name": "Smoothie & Juice Bar"
	}, 
	{
		"id": "191633160865760", 
		"name": "Snowmobiles"
	}, 
	{
		"id": "215343825145859", 
		"name": "Social Club"
	}, 
	{
		"id": "178669642178193", 
		"name": "Social Services"
	}, 
	{
		"id": "161521487230197", 
		"name": "Solar Energy Service"
	}, 
	{
		"id": "165264720195968", 
		"name": "Sorority & Fraternity"
	}, 
	{
		"id": "156757354384541", 
		"name": "Soul Food Restaurant"
	}, 
	{
		"id": "135468489860087", 
		"name": "Soup Restaurant"
	}, 
	{
		"id": "203693296307954", 
		"name": "Southern Restaurant"
	}, 
	{
		"id": "143722605691025", 
		"name": "Southwestern Restaurant"
	}, 
	{
		"id": "200814353265561", 
		"name": "Spa"
	}, 
	{
		"id": "171485526232801", 
		"name": "Spanish Restaurant"
	}, 
	{
		"id": "162264673824073", 
		"name": "Specialty Grocery Store"
	}, 
	{
		"id": "144971758897076", 
		"name": "Specialty School"
	}, 
	{
		"id": "192761027418354", 
		"name": "Speech Pathologist"
	}, 
	{
		"id": "165823830131654", 
		"name": "Sporting Goods Store"
	}, 
	{
		"id": "184460441595855", 
		"name": "Sports Bar"
	}, 
	{
		"id": "192998244062607", 
		"name": "Sports Center"
	}, 
	{
		"id": "189018581118681", 
		"name": "Sports Club"
	}, 
	{
		"id": "193302624020981", 
		"name": "Sports Instruction"
	}, 
	{
		"id": "124584130946507", 
		"name": "Sports Promoter"
	}, 
	{
		"id": "109976259083543", 
		"name": "Sports Venue & Stadium"
	}, 
	{
		"id": "181069735261656", 
		"name": "Sportswear"
	}, 
	{
		"id": "358483060859947", 
		"name": "Startup"
	}, 
	{
		"id": "218341394934388", 
		"name": "State"
	}, 
	{
		"id": "204506149664245", 
		"name": "State Park"
	}, 
	{
		"id": "210857662260088", 
		"name": "Statue & Fountain"
	}, 
	{
		"id": "198367566846946", 
		"name": "Steakhouse"
	}, 
	{
		"id": "163459287040281", 
		"name": "Storage"
	}, 
	{
		"id": "132521440149062", 
		"name": "Storage Service"
	}, 
	{
		"id": "151810238222781", 
		"name": "Street"
	}, 
	{
		"id": "342068002497936", 
		"name": "Subway & Light Rail Station"
	}, 
	{
		"id": "297681550307872", 
		"name": "Supply & Distribution Services"
	}, 
	{
		"id": "151723701557019", 
		"name": "Surfing Spot"
	}, 
	{
		"id": "164080003645425", 
		"name": "Surveyor"
	}, 
	{
		"id": "134501539950711", 
		"name": "Sushi Restaurant"
	}, 
	{
		"id": "124887510918208", 
		"name": "Swimming Pool"
	}, 
	{
		"id": "124760297597666", 
		"name": "Swimming Pool Maintenance"
	}, 
	{
		"id": "199659113384429", 
		"name": "Swimwear"
	}, 
	{
		"id": "181815448531059", 
		"name": "Symphony"
	}, 
	{
		"id": "184925784880952", 
		"name": "Synagogue"
	}, 
	{
		"id": "199146280116687", 
		"name": "Taiwanese Restaurant"
	}, 
	{
		"id": "132069576863996", 
		"name": "Take Out Restaurant"
	}, 
	{
		"id": "185600691480842", 
		"name": "Tanning Salon"
	}, 
	{
		"id": "120731481338075", 
		"name": "Tanning Salon Supplier"
	}, 
	{
		"id": "119869574758000", 
		"name": "Tapas Bar & Restaurant"
	}, 
	{
		"id": "196188420407122", 
		"name": "Tattoo & Piercing"
	}, 
	{
		"id": "133381803394214", 
		"name": "Tax Preparation"
	}, 
	{
		"id": "210561295621365", 
		"name": "Taxi"
	}, 
	{
		"id": "171385766240459", 
		"name": "Taxidermist"
	}, 
	{
		"id": "203462172997785", 
		"name": "Tea Room"
	}, 
	{
		"id": "198890520141354", 
		"name": "Technical Institute"
	}, 
	{
		"id": "164436443610134", 
		"name": "Teeth Whitening"
	}, 
	{
		"id": "197557456921449", 
		"name": "Telemarketing Service"
	}, 
	{
		"id": "187950394558510", 
		"name": "Tennis"
	}, 
	{
		"id": "212369748779358", 
		"name": "Tex-Mex Restaurant"
	}, 
	{
		"id": "185512691489656", 
		"name": "Textiles"
	}, 
	{
		"id": "179167895459033", 
		"name": "Thai Restaurant"
	}, 
	{
		"id": "173883042668223", 
		"name": "Theater"
	}, 
	{
		"id": "169954839717887", 
		"name": "Theatrical Equipment"
	}, 
	{
		"id": "187224924655149", 
		"name": "Theme Park"
	}, 
	{
		"id": "205429726142620", 
		"name": "Thrift or Consignment Store"
	}, 
	{
		"id": "166975666684060", 
		"name": "Ticket Sales"
	}, 
	{
		"id": "124581960948637", 
		"name": "Tire Dealer"
	}, 
	{
		"id": "196434697050078", 
		"name": "Tobacco Store"
	}, 
	{
		"id": "121775454565552", 
		"name": "Tools Service"
	}, 
	{
		"id": "128966563840349", 
		"name": "Airport"
	}, 
	{
		"id": "150060378385891", 
		"name": "Appliances"
	}, 
	{
		"id": "110290705711626", 
		"name": "Bar"
	}, 
	{
		"id": "197048876974331", 
		"name": "Book Store"
	}, 
	{
		"id": "224455390913969", 
		"name": "City"
	}, 
	{
		"id": "179943432047564", 
		"name": "Concert Venue"
	}, 
	{
		"id": "357899304273793", 
		"name": "Country"
	}, 
	{
		"id": "188234584533149", 
		"name": "Doctor"
	}, 
	{
		"id": "177246315652372", 
		"name": "Entertainer"
	}, 
	{
		"id": "192119584190796", 
		"name": "Event"
	}, 
	{
		"id": "192647794097278", 
		"name": "Home Decor"
	}, 
	{
		"id": "164243073639257", 
		"name": "Hotel"
	}, 
	{
		"id": "244600688971270", 
		"name": "Island"
	}, 
	{
		"id": "175416179179838", 
		"name": "Junior High School"
	}, 
	{
		"id": "129417183848258", 
		"name": "Just For Fun"
	}, 
	{
		"id": "132852590115660", 
		"name": "Kitchen Supplies"
	}, 
	{
		"id": "163581277042500", 
		"name": "Lake"
	}, 
	{
		"id": "209889829023118", 
		"name": "Landmark"
	}, 
	{
		"id": "169896676390222", 
		"name": "Library"
	}, 
	{
		"id": "147675701970583", 
		"name": "Middle School"
	}, 
	{
		"id": "194201147294761", 
		"name": "Mountain"
	}, 
	{
		"id": "197817313562497", 
		"name": "Museum"
	}, 
	{
		"id": "206555552714503", 
		"name": "Neighborhood"
	}, 
	{
		"id": "108366235907857", 
		"name": "Newspaper"
	}, 
	{
		"id": "110249975723427", 
		"name": "Office Supplies"
	}, 
	{
		"id": "369730359717478", 
		"name": "Other"
	}, 
	{
		"id": "181475575221097", 
		"name": "Photographer"
	}, 
	{
		"id": "191684877517919", 
		"name": "Publisher"
	}, 
	{
		"id": "407338945943828", 
		"name": "River"
	}, 
	{
		"id": "365182493518892", 
		"name": "School"
	}, 
	{
		"id": "189811544396762", 
		"name": "Tour Company"
	}, 
	{
		"id": "175657495818161", 
		"name": "Tour Guide"
	}, 
	{
		"id": "186825111351005", 
		"name": "Tourist Attraction"
	}, 
	{
		"id": "124947834245370", 
		"name": "Tourist Information"
	}, 
	{
		"id": "174972792548177", 
		"name": "Towing Service"
	}, 
	{
		"id": "178680352174443", 
		"name": "Toy Store"
	}, 
	{
		"id": "192338537450532", 
		"name": "Trade School"
	}, 
	{
		"id": "127806747288007", 
		"name": "Traffic School"
	}, 
	{
		"id": "205261602824861", 
		"name": "Trailer	Rental"
	}, 
	{
		"id": "145887745471348", 
		"name": "Train Station"
	}, 
	{
		"id": "132478556820146", 
		"name": "Translator"
	}, 
	{
		"id": "152367304818850", 
		"name": "Transportation Service"
	}, 
	{
		"id": "162914327091136", 
		"name": "Travel Agency"
	}, 
	{
		"id": "139975202732005", 
		"name": "Trophies & Engraving"
	}, 
	{
		"id": "139389149463981", 
		"name": "Truck Rental"
	}, 
	{
		"id": "154069014648270", 
		"name": "Truck Towing"
	}, 
	{
		"id": "205503056146172", 
		"name": "Turkish Restaurant"
	}, 
	{
		"id": "145296352197250", 
		"name": "Tutoring"
	}, 
	{
		"id": "199442556739626", 
		"name": "Upholstery Service"
	}, 
	{
		"id": "239455319478077", 
		"name": "Urban Farm"
	}, 
	{
		"id": "192686080759400", 
		"name": "Vacation Home Rental"
	}, 
	{
		"id": "200742186618963", 
		"name": "Vegetarian & Vegan Restaurant"
	}, 
	{
		"id": "185259971514191", 
		"name": "Vending Machine Service"
	}, 
	{
		"id": "162068413843305", 
		"name": "Veterinarian"
	}, 
	{
		"id": "211579738882707", 
		"name": "Video Games"
	}, 
	{
		"id": "155136917876965", 
		"name": "Vietnamese Restaurant"
	}, 
	{
		"id": "194127957280024", 
		"name": "Vintage Store"
	}, 
	{
		"id": "193363504026352", 
		"name": "Wallpaper"
	}, 
	{
		"id": "194267960602473", 
		"name": "Warehouse"
	}, 
	{
		"id": "121989644542468", 
		"name": "Waste Management"
	}, 
	{
		"id": "144587185601777", 
		"name": "Water Filtration & Treatment"
	}, 
	{
		"id": "174777552574651", 
		"name": "Water Park"
	}, 
	{
		"id": "187393124625179", 
		"name": "Web Design"
	}, 
	{
		"id": "200154933429705", 
		"name": "Web Development"
	}, 
	{
		"id": "191173027579272", 
		"name": "Wedding Planning"
	}, 
	{
		"id": "193542570664339", 
		"name": "Well Water Drilling Service"
	}, 
	{
		"id": "187070794658134", 
		"name": "Wholesale & Supply Store"
	}, 
	{
		"id": "143160019083147", 
		"name": "Wig Store"
	}, 
	{
		"id": "156982297694225", 
		"name": "Wildlife Sanctuary"
	}, 
	{
		"id": "180001142041484", 
		"name": "Wills & Estate Lawyer"
	}, 
	{
		"id": "192041444166324", 
		"name": "Window Service & Repair"
	}, 
	{
		"id": "192661127431931", 
		"name": "Wine Bar"
	}, 
	{
		"id": "209630435729071", 
		"name": "Winery & Vineyard"
	}, 
	{
		"id": "128753240528981", 
		"name": "Women's Clothing Store"
	}, 
	{
		"id": "182582595112411", 
		"name": "Women's Health"
	}, 
	{
		"id": "177721448951559", 
		"name": "Workplace & Office"
	}, 
	{
		"id": "186573994697103", 
		"name": "Writing Service"
	}, 
	{
		"id": "174832985894571", 
		"name": "Yoga & Pilates"
	}, 
	{
		"id": "181053558607965", 
		"name": "Youth Organization"
	}, 
	{
		"id": "135093679891459", 
		"name": "Zoo & Aquarium"
	}
]


