# go through category list, save all ids as inividual objects into index
# if the result has paging.next - you can use paging.cursors.after to retrieve the next query.

from base import BaseClass

import config

import facebook


class Indexer(BaseClass):

	def __init__(self):
		super(Indexer, self).__init__( )
		self.graph = facebook.GraphAPI(config.fb_token)

	def index(self, start_index=0):
		categories = config.categories

		if start_index:
			categories = categories[start_index:]

		for i, category in enumerate(categories):
			done = False
			page_id = None

			while not done:
				query = self.__build_query(category['name'], page_id)
				req = self.__run_query(query)

				pages = req['data']
				paging = req['paging']

				for page in pages:
					self.__insert(page)

				if 'next' not in paging:
					done = True
				else:
					print paging
					page_id = paging['cursors']['after']

			print "Finished Category Number: " + str(i+start_index) + " --> " + category['name']
			print "Found: " + str(len(pages)) + " Pages"
			print ""


	def __build_query(self, category, page_id):
		query = {"q": category, "type":"page"}
		if page_id:
			query['after'] = page_id

		return query

	def __run_query(self, query):
		req = self.graph.request("search", query)
		return req

	def __insert(self, page):
		counter = self.get_counter("indexer");
		timestamp = self.get_timestamp( )

		page['timestamp'] = timestamp

		insert_query = {
			"$set": page,
			"$setOnInsert": { "_id": counter }
		}

		collection = self.db['index'] # get collection named index
		collection.update({ "id": page['id'] }, insert_query, upsert=True, w=1)


indexer = Indexer( )
indexer.index( )




