"""
This is a program that will look through the indexes and rip out facebook data slowly.

1. looks through all indexed pages & stores likes / shares.
2. If share/likes is above threshold, add to "hit list" to keep a high frequency watch
3. If share / likes is below threshold, and is in hit list - remove from hit list.


FB_HIT_LIST_SCHEMA:
_____________________
pull_date :
page_id :
_____________________


* from high freq scraper docs *
FB_PAGE_SCHEMA:
_____________________
pull_date :
likes :
shares :
past_scrapes : past like and share data.
id :
hit_list_id : id if applicable
??????
_____________________

"""

from base import BaseClass

import config

import json
import sys

import pymongo
from scrapy.http import Request
from scrapy.spider import Spider

class LowFreq(BaseClass, Spider):
	name = "facebook_low_freq"

	def __init__(self):
		super(LowFreq, self).__init__( )
		collection = self.db['index']
		self.cursor = collection.find( ).sort('_id', pymongo.ASCENDING) # add limit query for date

		url = self.__generate_url( )

		# scrapy spider start point.
		self.start_urls = [ 
			url
		]


	def __get_page_id(self):
		page = next(self.cursor, None)
		if page is None:
			sys.exit(0)
		else:
			return page["id"]


	def __generate_url(self):
		page_id = self.__get_page_id( )
		return config.fb_public_endpoint % page_id


	# scrapy spider member function override
	def parse(self, response):
		self.__insert(response)

		url = self.__generate_url( )
		yield Request(url, callback = self.parse, headers = {'referer': None})


	def __insert(self, response):
		data = json.loads(response.body)
		print data

		# TODO









